"""
Exception classes for the GenSpark AI Drive SDK.
"""

from typing import Optional, Any


class AIDriveError(Exception):
    """Base exception for all AI Drive related errors."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response: Optional[Any] = None,
    ) -> None:
        """
        Initialize AIDriveError.

        Args:
            message: Error message
            status_code: HTTP status code if applicable
            response: Raw response object if available
        """
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response = response

    def __str__(self) -> str:
        """Return string representation of the error."""
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message


class AuthenticationError(AIDriveError):
    """Raised when there is an authentication error."""

    pass


class RemoteNotFoundError(AIDriveError):
    """Raised when a requested remote resource is not found."""

    pass


class PermissionError(AIDriveError):
    """Raised when permission is denied for a requested operation."""

    pass


class RateLimitError(AIDriveError):
    """Raised when the API rate limit is exceeded."""

    pass


class ValidationError(AIDriveError):
    """Raised when request validation fails (400 with validation errors)."""

    pass


class ConflictError(AIDriveError):
    """Raised when there is a resource conflict (e.g., file already exists)."""

    pass


class QuotaExceededError(AIDriveError):
    """Raised when storage quota is exceeded."""

    pass


class InvalidPathError(AIDriveError):
    """Raised when a path contains invalid format or characters."""

    pass


class ServerError(AIDriveError):
    """Raised when a server error occurs."""

    pass
