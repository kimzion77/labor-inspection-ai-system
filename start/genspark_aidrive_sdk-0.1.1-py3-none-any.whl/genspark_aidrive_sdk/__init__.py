"""
GenSpark AIDrive SDK - Python SDK for GenSpark AIDrive API
"""

from ._version import __version__
from .client import AIDriveClient
from .exceptions import (
    AIDriveError,
    AuthenticationError,
    RemoteNotFoundError,
    PermissionError,
    ValidationError,
    ConflictError,
    QuotaExceededError,
    InvalidPathError,
    ServerError,
)
from .models import (
    FileItem,
    FileListResponse,
    UploadResponse,
    DownloadResponse,
    DirectoryResponse,
    DeleteResponse,
    MoveResponse,
)
from . import cli

__all__ = [
    "__version__",
    "AIDriveClient",
    "AIDriveError",
    "AuthenticationError",
    "RemoteNotFoundError",
    "PermissionError",
    "ValidationError",
    "ConflictError",
    "QuotaExceededError",
    "InvalidPathError",
    "ServerError",
    "FileItem",
    "FileListResponse",
    "UploadResponse",
    "DownloadResponse",
    "DirectoryResponse",
    "DeleteResponse",
    "MoveResponse",
    "cli",
]
