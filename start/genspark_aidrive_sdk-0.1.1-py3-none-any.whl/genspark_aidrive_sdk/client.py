"""
AI Drive Client - Main interface for interacting with GenSpark AI Drive.
"""

import os
import json
import requests
from typing import Dict, Optional, Any
import mimetypes
from pathlib import Path

from .exceptions import (
    AIDriveError,
    AuthenticationError,
    RemoteNotFoundError,
    PermissionError,
    ValidationError,
    ConflictError,
    QuotaExceededError,
    ServerError,
)
from ._version import __version__
from .models import (
    FileItem,
    FileListResponse,
    UploadResponse,
    DownloadResponse,
    DirectoryResponse,
    DeleteResponse,
    MoveResponse,
    StorageUsageResponse,
)
from .utils import _validate_remote_path


class AIDriveClient:
    """Client for interacting with GenSpark AI Drive service."""

    # Namespace for the AI Drive API
    NAMESPACE = "files"

    def __init__(
        self,
        token: Optional[str] = None,
        base_url: Optional[str] = None,
        api_prefix: Optional[str] = None,
        route_identifier: Optional[str] = None,
        environment_id: Optional[str] = None,
    ):
        """
        Initialize the AI Drive client.

        Args:
            token: Authentication token for the API. If None, will look for
                  GENSPARK_TOKEN environment variable.
            base_url: Base URL of the GenSpark API. If None, will look for
                     GENSPARK_BASE_URL environment variable.
                     Defaults to "https://www.genspark.ai" if not set.
            api_prefix: API prefix for the AI Drive endpoints. If None, will look for
                       GENSPARK_AIDRIVE_API_PREFIX environment variable.
                       Defaults to "/api/aidrive" if not set.
            route_identifier: Route identifier for special network routing. If None, will look for
                            GENSPARK_ROUTE_IDENTIFIER environment variable.
            environment_id: Environment ID for the current running environment. If None, will look for
                          GENSPARK_ENVIRONMENT_ID environment variable.
        """
        # Get token from parameter or environment variable
        self.token = token or os.environ.get("GENSPARK_TOKEN")
        if not self.token:
            raise ValueError(
                "Authentication token must be provided either as an argument or via "
                "the GENSPARK_TOKEN environment variable."
            )

        # Get base_url from parameter or environment variable, with default
        self.base_url = (
            base_url or os.environ.get("GENSPARK_BASE_URL") or "https://www.genspark.ai"
        ).rstrip("/")

        # Get API prefix from parameter or environment variable, with default
        self.api_prefix = (
            api_prefix
            or os.environ.get("GENSPARK_AIDRIVE_API_PREFIX")
            or "/api/aidrive"
        )

        # Get route identifier from parameter or environment variable
        self.route_identifier = route_identifier or os.environ.get(
            "GENSPARK_ROUTE_IDENTIFIER"
        )

        # Get environment ID from parameter or environment variable
        self.environment_id = environment_id or os.environ.get(
            "GENSPARK_ENVIRONMENT_ID"
        )

        self.full_base_url = f"{self.base_url}{self.api_prefix}"
        self.session = requests.Session()

        # Build headers
        headers = {
            "Authorization": f"Bearer {self.token}",
            "User-Agent": f"GenSpark-AIDrive-SDK/{__version__}",
        }

        # Add custom route identifier header if set
        if self.route_identifier:
            headers["X-Route-Identifier"] = self.route_identifier

        # Add environment ID header if set
        if self.environment_id:
            headers["X-Environment-ID"] = self.environment_id

        self.session.headers.update(headers)

        # Check login status
        self._check_login_status()

    def _check_login_status(self) -> None:
        """Check if the user is logged in by calling /api/is_login."""
        try:
            # Make a request to the base URL (not aidrive specific) to check login status
            login_check_url = f"{self.base_url}/api/is_login"
            response = self.session.get(login_check_url)

            if response.status_code >= 400:
                raise AuthenticationError(
                    message="Failed to check login status",
                    status_code=response.status_code,
                    response=response.text,
                )

            data = response.json()

            # Check the response - looking for status -5 (not logged in) or is_login: false
            if data.get("status") == -5 or not data.get("data", {}).get(
                "is_login", True
            ):
                raise AuthenticationError(
                    message="Authentication failed. This appears to be an unauthorized runtime environment.",
                    status_code=401,
                    response=data,
                )

        except requests.exceptions.RequestException:
            # If we can't check login status, we should fail safe and continue
            # This could happen if the endpoint is not available
            pass

    def _handle_response(self, response: requests.Response) -> Dict[str, Any]:
        """Handle API response and raise appropriate exceptions."""
        if response.status_code >= 400:
            error_msg = f"API request failed with status {response.status_code}"
            response_data = None

            try:
                response_data = response.json()
                if "detail" in response_data:
                    error_msg = f"{error_msg}: {response_data['detail']}"
            except (json.JSONDecodeError, KeyError):
                if response.text:
                    error_msg = f"{error_msg}: {response.text}"

            # Map status codes to specific exception types
            if response.status_code == 401:
                raise AuthenticationError(
                    message=error_msg,
                    status_code=response.status_code,
                    response=response_data or response.text,
                )
            elif response.status_code == 403:
                raise PermissionError(
                    message=error_msg,
                    status_code=response.status_code,
                    response=response_data or response.text,
                )
            elif response.status_code == 404:
                raise RemoteNotFoundError(
                    message=error_msg,
                    status_code=response.status_code,
                    response=response_data or response.text,
                )
            elif response.status_code == 400:
                # Check error message for more specific error types
                error_detail = str(
                    response_data.get("detail", "") if response_data else response.text
                ).lower()
                if "not found" in error_detail:
                    raise RemoteNotFoundError(
                        message=error_msg,
                        status_code=response.status_code,
                        response=response_data or response.text,
                    )
                elif "already exists" in error_detail:
                    raise ConflictError(
                        message=error_msg,
                        status_code=response.status_code,
                        response=response_data or response.text,
                    )
                elif "quota exceeded" in error_detail:
                    raise QuotaExceededError(
                        message=error_msg,
                        status_code=response.status_code,
                        response=response_data or response.text,
                    )
                elif (
                    "cannot delete root" in error_detail
                    or "cannot move root" in error_detail
                ):
                    raise ValidationError(
                        message=error_msg,
                        status_code=response.status_code,
                        response=response_data or response.text,
                    )
                elif "invalid" in error_detail or "expired" in error_detail:
                    raise ValidationError(
                        message=error_msg,
                        status_code=response.status_code,
                        response=response_data or response.text,
                    )
                else:
                    raise ValidationError(
                        message=error_msg,
                        status_code=response.status_code,
                        response=response_data or response.text,
                    )
            elif response.status_code == 429:
                # Rate limit error
                raise AIDriveError(
                    message=error_msg,
                    status_code=response.status_code,
                    response=response_data or response.text,
                )
            elif response.status_code >= 500:
                raise ServerError(
                    message=error_msg,
                    status_code=response.status_code,
                    response=response_data or response.text,
                )
            else:
                # Default to base exception for other status codes
                raise AIDriveError(
                    message=error_msg,
                    status_code=response.status_code,
                    response=response_data or response.text,
                )

        if response.status_code == 204:  # No content
            return {}

        try:
            result: Dict[str, Any] = response.json()
            return result
        except json.JSONDecodeError:
            # For non-JSON responses, return the raw content
            content_result: Dict[str, Any] = {
                "content": response.content,
            }
            return content_result

    def _filter_internal_fields(self, item: Dict[str, Any]) -> Dict[str, Any]:
        """Filter out internal fields from API response items."""
        # Fields to exclude from public API
        internal_fields = {"id", "parent_id"}

        # Create a new dict without internal fields
        filtered_item = {k: v for k, v in item.items() if k not in internal_fields}
        return filtered_item

    def list_files(
        self, path: str = "/", limit: Optional[int] = None
    ) -> FileListResponse:
        """
        List files and directories at the specified path.

        Args:
            path: Path to list files from. Defaults to root directory '/'.
                  Must start with '/'.
            limit: Maximum number of items to return. If None, returns all items.

        Returns:
            FileListResponse containing the list of files and directories.

        Raises:
            InvalidPathError: If path doesn't start with '/' or contains invalid characters.
        """
        # Validate and normalize the path
        validated_path = _validate_remote_path(path)

        # Strip leading slash for API call (API expects paths without leading slash)
        api_path = validated_path.lstrip("/")
        url = f"{self.full_base_url}/ls/{self.NAMESPACE}/{api_path}"

        # Add limit parameter if specified
        params = {}
        if limit is not None:
            params["limit"] = limit

        response = self.session.get(url, params=params)
        raw_data = self._handle_response(response)

        # Filter internal fields from each item
        if "items" in raw_data:
            filtered_items = []
            for item in raw_data["items"]:
                filtered_item = self._filter_internal_fields(item)
                try:
                    file_item = FileItem(**filtered_item)
                    filtered_items.append(file_item)
                except Exception:
                    # If validation fails, skip this item or log the error
                    continue

            return FileListResponse(
                items=filtered_items,
                path=validated_path,
                total_count=len(filtered_items),
            )

        # Fallback for unexpected response format
        return FileListResponse(items=[], path=validated_path, total_count=0)

    def upload_file(
        self,
        file_path: str,
        target_path: str,
    ) -> UploadResponse:
        """
        Upload a file to AI Drive.

        Args:
            file_path: Path to the local file to upload.
            target_path: Target path on AIDrive where file should be uploaded.
                        Must start with '/'.

        Returns:
            UploadResponse containing information about the uploaded file.

        Raises:
            FileNotFoundError: If the local file doesn't exist.
            InvalidPathError: If target_path doesn't start with '/' or contains invalid characters.
        """
        local_path = Path(file_path)
        if not local_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        # Validate and normalize the target path
        validated_path = _validate_remote_path(target_path)

        # Strip leading slash for API call
        api_path = validated_path.lstrip("/")

        # Get the file's MIME type
        mime_type = mimetypes.guess_type(local_path)[0] or "application/octet-stream"
        file_size = local_path.stat().st_size

        # Get upload URL
        upload_url_endpoint = (
            f"{self.full_base_url}/get_upload_url/{self.NAMESPACE}/{api_path}"
        )
        response = self.session.get(upload_url_endpoint)
        upload_data = self._handle_response(response)

        if "data" not in upload_data:
            raise AIDriveError(f"Failed to get upload URL: {upload_data}")

        # Upload the file directly to the provided URL
        with open(local_path, "rb") as file_obj:
            upload_url = upload_data["data"]["upload_url"]
            # Add specific headers required for Azure Blob Storage
            headers = {"x-ms-blob-type": "BlockBlob", "Content-Type": mime_type}
            upload_response = requests.put(upload_url, data=file_obj, headers=headers)

            if upload_response.status_code >= 400:
                raise AIDriveError(
                    f"Upload failed with status {upload_response.status_code}: "
                    f"{upload_response.text}"
                )

        # Confirm upload with the token
        token = upload_data["data"]["token"]

        confirm_url = f"{self.full_base_url}/confirm_upload/{self.NAMESPACE}/{api_path}"
        confirm_data = {"token": token, "mime_type": mime_type}

        response = self.session.post(confirm_url, json=confirm_data)
        self._handle_response(response)

        return UploadResponse(
            file_path=validated_path,
            message="File uploaded successfully",
            size=file_size,
            mime_type=mime_type,
        )

    def download_file(
        self, path: str, destination: Optional[str] = None
    ) -> DownloadResponse:
        """
        Download a file from AI Drive.

        Args:
            path: Path of the file to download. Must start with '/'.
            destination: Local path where the file should be saved.
                         If None, saves to current directory with same filename.

        Returns:
            DownloadResponse containing information about the downloaded file.

        Raises:
            InvalidPathError: If path doesn't start with '/' or contains invalid characters.
        """
        # Validate and normalize the path
        validated_path = _validate_remote_path(path)

        # Strip leading slash for API call
        api_path = validated_path.lstrip("/")
        url = f"{self.full_base_url}/download/{self.NAMESPACE}/{api_path}"

        response = self.session.get(url, stream=True)

        if response.status_code >= 400:
            self._handle_response(response)  # Will raise appropriate exception

        if destination is None:
            filename = validated_path.split("/")[-1]
            destination = filename

        # Create directories if needed
        dest_path = Path(destination)
        dest_path.parent.mkdir(parents=True, exist_ok=True)

        # Check if file already exists to maintain consistency with upload behavior
        if dest_path.exists():
            raise ConflictError(
                f"Local file already exists: {dest_path}. "
                "Delete the existing file first or specify a different destination."
            )

        total_size = 0
        with open(dest_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    total_size += len(chunk)

        return DownloadResponse(
            remote_path=validated_path,
            local_path=str(dest_path.absolute()),
            size=total_size,
        )

    def create_directory(self, path: str) -> DirectoryResponse:
        """
        Create a directory on AI Drive.

        Args:
            path: Path of the directory to create. Must start with '/'.

        Returns:
            DirectoryResponse containing the result of the operation.

        Raises:
            InvalidPathError: If path doesn't start with '/' or contains invalid characters.
        """
        # Validate and normalize the path
        validated_path = _validate_remote_path(path)

        # Strip leading slash for API call
        api_path = validated_path.lstrip("/")
        url = f"{self.full_base_url}/mkdir/{self.NAMESPACE}/{api_path}"

        response = self.session.post(url)
        self._handle_response(response)

        return DirectoryResponse(
            path=validated_path, message="Directory created successfully"
        )

    def delete_item(self, path: str) -> DeleteResponse:
        """
        Delete a file or directory on AI Drive.

        Args:
            path: Path of the item to delete. Must start with '/'.

        Returns:
            DeleteResponse containing the result of the operation.

        Raises:
            InvalidPathError: If path doesn't start with '/' or contains invalid characters.
        """
        # Validate and normalize the path
        validated_path = _validate_remote_path(path)

        # Strip leading slash for API call
        api_path = validated_path.lstrip("/")
        url = f"{self.full_base_url}/delete/{self.NAMESPACE}/{api_path}"

        response = self.session.delete(url)
        self._handle_response(response)

        return DeleteResponse(path=validated_path, message="Item deleted successfully")

    def move_item(self, src_path: str, dst_path: str) -> MoveResponse:
        """
        Move or rename a file or directory on AI Drive (behaves like Unix mv command).

        Args:
            src_path: Source path to move from. Must start with '/'.
            dst_path: Destination path to move to. Must start with '/'.

        Returns:
            MoveResponse containing the result of the operation.

        Raises:
            InvalidPathError: If either path doesn't start with '/' or contains invalid characters.
        """
        # Validate and normalize both paths
        validated_src = _validate_remote_path(src_path)
        validated_dst = _validate_remote_path(dst_path)

        url = f"{self.full_base_url}/move"
        data = {"src_path": validated_src, "dst_path": validated_dst}

        response = self.session.post(url, json=data)
        self._handle_response(response)

        return MoveResponse(
            src_path=validated_src,
            dst_path=validated_dst,
            message="Item moved successfully",
        )

    def get_storage_usage(self) -> StorageUsageResponse:
        """
        Get current storage usage information.

        Returns:
            StorageUsageResponse containing storage plan, quota and usage information.

        Raises:
            AIDriveError: If the request fails.
        """
        url = f"{self.full_base_url}/storage_usage"
        response = self.session.get(url)
        raw_data = self._handle_response(response)

        if "data" in raw_data:
            return StorageUsageResponse(**raw_data["data"])

        # Handle unexpected response format
        raise AIDriveError("Unexpected response format for storage usage")
