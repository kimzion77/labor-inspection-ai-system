"""
Data models for the GenSpark AI Drive SDK.
"""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field


class FileItem(BaseModel):
    """Represents a file or directory item in AI Drive."""

    name: str = Field(..., description="Name of the file or directory")
    path: str = Field(..., description="Full path of the item")
    type: str = Field(..., description="Type of item: 'file' or 'directory'")
    size: int = Field(..., description="Size in bytes (0 for directories)")
    modified_time: int = Field(..., description="Last modified time as Unix timestamp")
    mime_type: Optional[str] = Field(None, description="MIME type for files")

    @property
    def is_directory(self) -> bool:
        """Check if this item is a directory."""
        return self.type == "directory"

    @property
    def is_file(self) -> bool:
        """Check if this item is a file."""
        return self.type == "file"

    @property
    def modified_datetime(self) -> datetime:
        """Get modified time as datetime object."""
        return datetime.fromtimestamp(self.modified_time)

    class Config:
        """Pydantic configuration."""

        json_encoders = {datetime: lambda dt: dt.isoformat()}


class FileListResponse(BaseModel):
    """Response for listing files."""

    items: List[FileItem] = Field(..., description="List of files and directories")
    path: str = Field(..., description="Path that was listed")
    total_count: int = Field(..., description="Total number of items in the response")

    class Config:
        """Pydantic configuration."""

        json_encoders = {datetime: lambda dt: dt.isoformat()}


class UploadResponse(BaseModel):
    """Response for file upload operations."""

    file_path: str = Field(..., description="Path where the file was uploaded")
    message: Optional[str] = Field(None, description="Additional message")
    size: Optional[int] = Field(None, description="Size of uploaded file")
    mime_type: Optional[str] = Field(None, description="MIME type of uploaded file")


class DownloadResponse(BaseModel):
    """Response for file download operations."""

    remote_path: str = Field(..., description="Remote path that was downloaded")
    local_path: str = Field(..., description="Local path where file was saved")
    size: Optional[int] = Field(None, description="Size of downloaded file")


class DirectoryResponse(BaseModel):
    """Response for directory operations."""

    path: str = Field(..., description="Path of the directory")
    message: Optional[str] = Field(None, description="Additional message")


class DeleteResponse(BaseModel):
    """Response for delete operations."""

    path: str = Field(..., description="Path that was deleted")
    message: Optional[str] = Field(None, description="Additional message")


class MoveResponse(BaseModel):
    """Response for move operations."""

    src_path: str = Field(..., description="Source path")
    dst_path: str = Field(..., description="Destination path")
    message: Optional[str] = Field(None, description="Additional message")


class StorageUsageResponse(BaseModel):
    """Response for storage usage information."""

    plan: str = Field(..., description="Current storage plan")
    quota_bytes: int = Field(..., description="Total storage quota in bytes")
    used_bytes: int = Field(..., description="Used storage in bytes")

    @property
    def quota_gb(self) -> float:
        """Get quota in GB."""
        return self.quota_bytes / (1024**3)

    @property
    def used_gb(self) -> float:
        """Get used storage in GB."""
        return self.used_bytes / (1024**3)

    @property
    def used_percentage(self) -> float:
        """Get percentage of storage used."""
        if self.quota_bytes == 0:
            return 0.0
        return (self.used_bytes / self.quota_bytes) * 100

    @property
    def available_bytes(self) -> int:
        """Get available storage in bytes."""
        return max(0, self.quota_bytes - self.used_bytes)

    @property
    def available_gb(self) -> float:
        """Get available storage in GB."""
        return self.available_bytes / (1024**3)


# Legacy models for backward compatibility (deprecated)
class User(BaseModel):
    """Represents a user in the AI Drive system."""

    id: str
    name: str
    email: str


class FileMetadata(BaseModel):
    """Metadata for a file in AI Drive."""

    id: str
    name: str
    type: str
    size: int
    created_at: datetime
    modified_at: datetime
    owner: User
    parent_id: Optional[str] = None
    shared_with: List[User] = Field(default_factory=list)
    mime_type: Optional[str] = None
    is_directory: bool = False
    thumbnail_url: Optional[str] = None

    class Config:
        """Pydantic configuration."""

        json_encoders = {datetime: lambda dt: dt.isoformat()}
