"""
Utility functions for the GenSpark AI Drive SDK.
"""

import os
import json
import hashlib
from typing import Dict, Any, Union, List
from pathlib import Path
import mimetypes
import urllib.parse
import unicodedata

from .exceptions import InvalidPathError


def normalize_path(path: str) -> str:
    """
    Normalize a path to ensure it has a leading slash but not a trailing slash.

    Args:
        path: Path to normalize

    Returns:
        Normalized path
    """
    if not path:
        return "/"

    path = path.strip()
    if not path.startswith("/"):
        path = "/" + path

    if path != "/" and path.endswith("/"):
        path = path.rstrip("/")

    return path


def _is_safe_path_character(char: str) -> bool:
    """
    Check if a character is allowed in Linux file paths.

    Linux filesystems only prohibit two characters in filenames:
    - '/' (path separator)
    - '\\0' (null terminator)

    All other characters, including control characters and "special" characters
    like <, >, :, *, ?, |, \\, are perfectly legal in Linux filenames.

    Args:
        char: Character to check

    Returns:
        True if character is allowed in Linux filenames
    """
    # Only two characters are actually forbidden in Linux filenames
    if char == '/':   # Path separator - not allowed in filename components
        return False
    if char == '\0':  # Null terminator - not allowed anywhere
        return False

    # Everything else is legal in Linux, including:
    # - All control characters (tabs, newlines, etc.)
    # - All "Windows reserved" characters (<>:*?|\\)
    # - All Unicode characters
    # - Spaces, quotes, brackets, etc.
    return True


def _validate_remote_path(path: str) -> str:
    """
    Validate and normalize a remote path for AIDrive using modern, elegant approach.

    This function uses Unicode normalization and intelligent character validation
    instead of rigid regex patterns, making it more robust and maintainable.

    Rules:
    - All paths must start with '/'
    - Empty string or None is NOT allowed - must explicitly use '/' for root
    - Paths are Unicode-normalized and validated for safety
    - Multiple consecutive slashes are reduced to single slash

    Args:
        path: Path to validate

    Returns:
        Validated and normalized path

    Raises:
        InvalidPathError: If path is empty, doesn't start with '/' or contains invalid characters
    """
    if not path:
        raise InvalidPathError("Path cannot be empty. Use '/' for root directory.")

    # Strip whitespace and normalize Unicode
    path = unicodedata.normalize('NFC', path.strip())

    # Check if path starts with /
    if not path.startswith("/"):
        raise InvalidPathError(f"Path must start with '/'. Got: '{path}'")

    # Normalize multiple slashes first
    while "//" in path:
        path = path.replace("//", "/")

    # Special case: root path is always valid (check after normalization)
    if path == "/":
        return path

    # Remove trailing slash except for root
    if path.endswith("/"):
        path = path.rstrip("/")

    # Split path into components and validate each part
    path_parts = path.split('/')[1:]  # Skip empty first part from leading '/'

    for part in path_parts:
        if not part:  # Empty part (should not happen after normalization)
            continue

        # Check for obviously problematic characters using elegant character validation
        for char in part:
            if not _is_safe_path_character(char):
                raise InvalidPathError(f"Path contains unsafe character '{char}' in component '{part}': '{path}'")

        # Check component length (filesystem limits)
        if len(part.encode('utf-8')) > 255:  # Most filesystems limit filename to 255 bytes
            raise InvalidPathError(f"Path component too long: '{part}' in path '{path}'")

    # Check total path length
    if len(path.encode('utf-8')) > 4096:  # Reasonable total path limit
        raise InvalidPathError(f"Path too long (max 4096 bytes): '{path}'")

    return path


def url_encode_path_component(component: str) -> str:
    """
    URL-encode a path component while preserving readability for common characters.

    This is a more elegant alternative to regex-based validation that could be used
    for systems requiring stricter character encoding.

    Args:
        component: Path component to encode

    Returns:
        URL-encoded component safe for transmission
    """
    # Preserve common safe characters, encode others
    # Safe characters: letters, digits, and common punctuation that's filesystem-safe
    safe_chars = '-_.()[]\'\"&%#@!+=,;: '
    return urllib.parse.quote(component, safe=safe_chars)


def url_encode_path(path: str) -> str:
    """
    URL-encode entire path while preserving path structure.

    Args:
        path: Full path to encode

    Returns:
        URL-encoded path
    """
    if not path or path == '/':
        return path

    parts = path.split('/')
    encoded_parts = []

    for i, part in enumerate(parts):
        if i == 0:  # First part is empty due to leading slash
            encoded_parts.append('')
        elif part:  # Non-empty parts
            encoded_parts.append(url_encode_path_component(part))
        else:  # Empty parts (shouldn't happen in normalized paths)
            encoded_parts.append('')

    return '/'.join(encoded_parts)


def get_mime_type(file_path: Union[str, Path]) -> str:
    """
    Get the MIME type of a file.

    Args:
        file_path: Path to the file

    Returns:
        MIME type of the file
    """
    file_path = str(file_path)
    mime_type, _ = mimetypes.guess_type(file_path)
    return mime_type or "application/octet-stream"


def get_file_size(file_path: Union[str, Path]) -> int:
    """
    Get the size of a file in bytes.

    Args:
        file_path: Path to the file

    Returns:
        Size of the file in bytes
    """
    path = Path(file_path)
    return path.stat().st_size


def is_binary_file(file_path: Union[str, Path]) -> bool:
    """
    Check if a file is a binary file.

    Args:
        file_path: Path to the file

    Returns:
        True if the file is binary, False otherwise
    """
    mime_type = get_mime_type(file_path)
    return mime_type.startswith("application/") and mime_type != "application/json"


def build_directory_tree(files: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Build a directory tree from a list of files.

    Args:
        files: List of file objects

    Returns:
        Directory tree structure
    """
    tree: Dict[str, Any] = {"name": "/", "type": "directory", "children": {}}

    for file in files:
        path_parts = file["path"].strip("/").split("/")
        current_level = tree

        # Navigate to the correct level in the tree
        for i, part in enumerate(path_parts[:-1]):
            if part not in current_level["children"]:
                current_level["children"][part] = {
                    "name": part,
                    "type": "directory",
                    "children": {},
                }
            current_level = current_level["children"][part]

        # Add the file/directory to the current level
        if file["type"] == "directory":
            if path_parts[-1] not in current_level["children"]:
                current_level["children"][path_parts[-1]] = {
                    "name": path_parts[-1],
                    "type": "directory",
                    "children": {},
                }
        else:
            current_level["children"][path_parts[-1]] = {
                "name": path_parts[-1],
                "type": "file",
                "id": file.get("id", ""),
                "size": file.get("size", 0),
                "mime_type": file.get("mime_type", ""),
                "modified": file.get("modified", ""),
            }

    return tree


def calculate_file_hash(file_path: str, algorithm: str = "sha256") -> str:
    """
    Calculate the hash of a file.

    Args:
        file_path: Path to the file
        algorithm: Hash algorithm to use

    Returns:
        File hash as a hexadecimal string
    """
    hash_obj = hashlib.new(algorithm)

    with open(file_path, "rb") as f:
        # Read and update hash in chunks to avoid loading large files into memory
        for chunk in iter(lambda: f.read(4096), b""):
            hash_obj.update(chunk)

    return hash_obj.hexdigest()


def validate_file_path(file_path: str) -> bool:
    """
    Validate that a file path exists and is readable.

    Args:
        file_path: Path to validate

    Returns:
        True if the file exists and is readable, False otherwise
    """
    return os.path.isfile(file_path) and os.access(file_path, os.R_OK)


def parse_api_response(response_text: str) -> Dict[str, Any]:
    """
    Parse an API response from JSON.

    Args:
        response_text: JSON response text

    Returns:
        Parsed response as a dictionary
    """
    try:
        result: Dict[str, Any] = json.loads(response_text)
        return result
    except json.JSONDecodeError:
        # Return a basic error if not JSON
        return {"error": "Invalid JSON response", "raw_response": response_text}
