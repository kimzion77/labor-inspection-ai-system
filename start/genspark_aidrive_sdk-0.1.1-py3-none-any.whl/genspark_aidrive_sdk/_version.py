"""Version information for GenSpark AIDrive SDK."""

__version__ = "0.1.1"
