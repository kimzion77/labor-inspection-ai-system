#!/usr/bin/env python3
"""
GenSpark AIDrive SDK - Command Line Interface

Native CLI support for the AIDrive SDK, providing easy access to all file operations
through command line interface.
"""

import os
import sys
import argparse
from typing import Any
import json

from .client import AIDriveClient
from .exceptions import AIDriveError, InvalidPathError
from ._version import __version__
from .utils import _validate_remote_path


def print_json(data: Any) -> None:
    """Print data in a formatted JSON way."""
    if hasattr(data, "dict"):
        # Pydantic model
        print(json.dumps(data.dict(), indent=2, ensure_ascii=False))
    elif isinstance(data, dict):
        print(json.dumps(data, indent=2, ensure_ascii=False))
    else:
        print(json.dumps(str(data), indent=2, ensure_ascii=False))


def print_success(message: str) -> None:
    """Print success message with green color if terminal supports it."""
    try:
        # Try to use colors if available
        print(f"\033[92m✓ {message}\033[0m")
    except Exception:
        print(f"✓ {message}")


def print_error(message: str) -> None:
    """Print error message with red color if terminal supports it."""
    try:
        # Try to use colors if available
        print(f"\033[91m✗ {message}\033[0m", file=sys.stderr)
    except Exception:
        print(f"✗ {message}", file=sys.stderr)


def print_info(message: str) -> None:
    """Print info message with blue color if terminal supports it."""
    try:
        # Try to use colors if available
        print(f"\033[94mℹ {message}\033[0m")
    except Exception:
        print(f"ℹ {message}")


def create_parser() -> argparse.ArgumentParser:
    """Create and configure the argument parser."""
    parser = argparse.ArgumentParser(
        prog="aidrive",
        description="GenSpark AIDrive CLI - Manage files in AIDrive cloud storage",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  aidrive list /                           # List files in root directory
  aidrive upload local.txt /remote.txt     # Upload a file
  aidrive download /remote.txt local.txt   # Download a file
  aidrive mkdir /new_folder                # Create a directory
  aidrive move /old.txt /new.txt           # Move/rename a file
  aidrive delete /unwanted.txt             # Delete a file or directory
  aidrive storage-usage                    # Check storage usage and quota

Environment Variables:
  GENSPARK_TOKEN      # Authentication token (required)
  GENSPARK_BASE_URL   # API base URL (optional)
  GENSPARK_AIDRIVE_API_PREFIX  # API prefix (optional)
  GENSPARK_ROUTE_IDENTIFIER    # Route identifier for special network routing (optional)
  GENSPARK_ENVIRONMENT_ID      # Environment ID for current running environment (optional)

For more information, visit: https://github.com/genspark/aidrive-sdk
        """,
    )

    # Global options
    parser.add_argument(
        "--version", "-V", action="version", version=f"AIDrive CLI v{__version__}"
    )

    parser.add_argument("--token", "-t", help="Authentication token for AIDrive API")
    parser.add_argument("--base-url", "-u", help="Base URL of the AIDrive API")
    parser.add_argument("--api-prefix", help="API prefix for AIDrive endpoints")
    parser.add_argument(
        "--route-identifier", help="Route identifier for special network routing"
    )
    parser.add_argument(
        "--environment-id", help="Environment ID for current running environment"
    )

    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Enable verbose output"
    )

    parser.add_argument(
        "--quiet", "-q", action="store_true", help="Suppress non-essential output"
    )

    # Subcommands
    subparsers = parser.add_subparsers(
        dest="command", help="Available commands", metavar="COMMAND"
    )

    # List command
    list_parser = subparsers.add_parser(
        "list", aliases=["ls"], help="List files and directories"
    )
    list_parser.add_argument(
        "path", nargs="?", default="/", help="Path to list (default: root directory)"
    )
    list_parser.add_argument(
        "--limit", "-l", type=int, help="Limit the number of items to display"
    )

    # Upload command
    upload_parser = subparsers.add_parser(
        "upload", aliases=["up"], help="Upload a file to AIDrive"
    )
    upload_parser.add_argument("source", help="Local file path to upload")
    upload_parser.add_argument(
        "destination", help="Remote path where file should be stored"
    )

    # Download command
    download_parser = subparsers.add_parser(
        "download", aliases=["down", "dl"], help="Download a file from AIDrive"
    )
    download_parser.add_argument("source", help="Remote file path to download")
    download_parser.add_argument(
        "destination",
        nargs="?",
        help="Local path where file should be saved (default: current directory)",
    )

    # Create directory command
    mkdir_parser = subparsers.add_parser("mkdir", help="Create a directory")
    mkdir_parser.add_argument("path", help="Directory path to create")

    # Move/rename command
    move_parser = subparsers.add_parser(
        "move", aliases=["mv", "rename"], help="Move or rename a file/directory"
    )
    move_parser.add_argument("source", help="Source path")
    move_parser.add_argument("destination", help="Destination path")

    # Delete command
    delete_parser = subparsers.add_parser(
        "delete", aliases=["del", "rm"], help="Delete a file or directory"
    )
    delete_parser.add_argument("path", help="Path to delete")
    delete_parser.add_argument(
        "--force", "-f", action="store_true", help="Force deletion without confirmation"
    )

    # Check auth command
    subparsers.add_parser(
        "check-auth", aliases=["auth"], help="Check authentication status"
    )

    # Storage usage command
    subparsers.add_parser(
        "storage-usage",
        aliases=["usage", "quota"],
        help="Check storage usage and quota",
    )

    return parser


def execute_list(client: AIDriveClient, args: argparse.Namespace) -> int:
    """Execute list command."""
    try:
        # Validate path before displaying
        try:
            validated_path = _validate_remote_path(args.path)
        except InvalidPathError as e:
            print_error(str(e))
            return 1

        if not args.quiet:
            print_info(f"Listing files at: {validated_path}")

        result = client.list_files(args.path, limit=args.limit)

        if args.verbose:
            print_json(result)
        else:
            # Simple file listing using the new FileListResponse model
            if result.items:
                for item in result.items:
                    item_type = "📁" if item.is_directory else "📄"
                    size_info = ""
                    if not item.is_directory and item.size > 0:
                        # Format file size in human readable format
                        if item.size < 1024:
                            size_info = f" ({item.size}B)"
                        elif item.size < 1024 * 1024:
                            size_info = f" ({item.size / 1024:.1f}KB)"
                        else:
                            size_info = f" ({item.size / (1024 * 1024):.1f}MB)"

                    print(f"{item_type} {item.name}{size_info}")
            else:
                print_info("No files found")

        if not args.quiet:
            total_count = result.total_count or len(result.items)
            if args.limit and len(result.items) < total_count:
                print_success(f"Showing {len(result.items)} of {total_count} items")
            else:
                print_success(f"Listed {total_count} items")
        return 0
    except InvalidPathError as e:
        print_error(f"Invalid path: {e}")
        return 1
    except Exception as e:
        print_error(f"Failed to list files: {e}")
        return 1


def execute_upload(client: AIDriveClient, args: argparse.Namespace) -> int:
    """Execute upload command."""
    try:
        if not os.path.exists(args.source):
            print_error(f"Local file not found: {args.source}")
            return 1

        # Validate destination path
        try:
            validated_dest = _validate_remote_path(args.destination)
        except InvalidPathError as e:
            print_error(str(e))
            return 1

        if not args.quiet:
            print_info(f"Uploading {args.source} to {validated_dest}")

        result = client.upload_file(args.source, args.destination)

        if args.verbose:
            print_json(result)

        if not args.quiet:
            size_info = ""
            if result.size:
                if result.size < 1024:
                    size_info = f" ({result.size}B)"
                elif result.size < 1024 * 1024:
                    size_info = f" ({result.size / 1024:.1f}KB)"
                else:
                    size_info = f" ({result.size / (1024 * 1024):.1f}MB)"

            print_success(
                f"File uploaded successfully to {result.file_path}{size_info}"
            )
        return 0
    except InvalidPathError as e:
        print_error(f"Invalid path: {e}")
        return 1
    except Exception as e:
        print_error(f"Failed to upload file: {e}")
        return 1


def execute_download(client: AIDriveClient, args: argparse.Namespace) -> int:
    """Execute download command."""
    try:
        # Validate source path
        try:
            validated_src = _validate_remote_path(args.source)
        except InvalidPathError as e:
            print_error(str(e))
            return 1

        if not args.quiet:
            destination_msg = args.destination or "current directory"
            print_info(f"Downloading {validated_src} to {destination_msg}")

        result = client.download_file(args.source, args.destination)

        if args.verbose:
            print_json(result)

        if not args.quiet:
            size_info = ""
            if result.size:
                if result.size < 1024:
                    size_info = f" ({result.size}B)"
                elif result.size < 1024 * 1024:
                    size_info = f" ({result.size / 1024:.1f}KB)"
                else:
                    size_info = f" ({result.size / (1024 * 1024):.1f}MB)"

            print_success(f"File downloaded to: {result.local_path}{size_info}")
        return 0
    except InvalidPathError as e:
        print_error(f"Invalid path: {e}")
        return 1
    except Exception as e:
        print_error(f"Failed to download file: {e}")
        return 1


def execute_mkdir(client: AIDriveClient, args: argparse.Namespace) -> int:
    """Execute mkdir command."""
    try:
        # Validate path
        try:
            validated_path = _validate_remote_path(args.path)
        except InvalidPathError as e:
            print_error(str(e))
            return 1

        if not args.quiet:
            print_info(f"Creating directory: {validated_path}")

        result = client.create_directory(args.path)

        if args.verbose:
            print_json(result)

        if not args.quiet:
            message = result.message or f"Directory created: {result.path}"
            print_success(message)
        return 0
    except InvalidPathError as e:
        print_error(f"Invalid path: {e}")
        return 1
    except Exception as e:
        print_error(f"Failed to create directory: {e}")
        return 1


def execute_move(client: AIDriveClient, args: argparse.Namespace) -> int:
    """Execute move command."""
    try:
        # Validate both paths
        try:
            validated_src = _validate_remote_path(args.source)
            validated_dst = _validate_remote_path(args.destination)
        except InvalidPathError as e:
            print_error(str(e))
            return 1

        if not args.quiet:
            print_info(f"Moving {validated_src} to {validated_dst}")

        result = client.move_item(args.source, args.destination)

        if args.verbose:
            print_json(result)

        if not args.quiet:
            message = result.message or f"Moved {result.src_path} to {result.dst_path}"
            print_success(message)
        return 0
    except InvalidPathError as e:
        print_error(f"Invalid path: {e}")
        return 1
    except Exception as e:
        print_error(f"Failed to move item: {e}")
        return 1


def execute_delete(client: AIDriveClient, args: argparse.Namespace) -> int:
    """Execute delete command."""
    try:
        # Validate path
        try:
            validated_path = _validate_remote_path(args.path)
        except InvalidPathError as e:
            print_error(str(e))
            return 1

        # Confirmation for safety
        if not args.force:
            # Check if we're in an interactive terminal
            if sys.stdin.isatty():
                response = input(
                    f"Are you sure you want to delete '{validated_path}'? (y/N): "
                )
                if response.lower() not in ["y", "yes"]:
                    print_info("Delete operation cancelled")
                    return 0
            else:
                # Non-interactive environment without --force flag
                print_error(
                    "Delete operation requires confirmation. Use --force flag in non-interactive environments."
                )
                return 1

        if not args.quiet:
            print_info(f"Deleting: {validated_path}")

        result = client.delete_item(args.path)

        if args.verbose:
            print_json(result)

        if not args.quiet:
            message = result.message or f"Deleted: {result.path}"
            print_success(message)
        return 0
    except InvalidPathError as e:
        print_error(f"Invalid path: {e}")
        return 1
    except Exception as e:
        print_error(f"Failed to delete item: {e}")
        return 1


def execute_check_auth(client: AIDriveClient, args: argparse.Namespace) -> int:
    """Execute check-auth command."""
    try:
        # Try to make a request to check login status
        login_check_url = f"{client.base_url}/api/is_login"
        response = client.session.get(login_check_url)

        if response.status_code >= 400:
            print_error(
                f"Failed to check authentication status (HTTP {response.status_code})"
            )
            return 1

        data = response.json()

        # Check the response
        if data.get("status") == -5 or not data.get("data", {}).get("is_login", True):
            print_error("Authentication failed")
            print_info(
                "This appears to be an unauthorized runtime environment. All permissions should be pre-configured."
            )
            return 1

        # User is logged in
        user_data = data.get("data", {})
        cogen_id = user_data.get("cogen_id", "Unknown")
        cogen_name = user_data.get("cogen_name", "Unknown")

        print_success("Authentication successful")
        if not args.quiet:
            print_info(f"User: {cogen_name}")
            if args.verbose:
                print_info(f"User ID: {cogen_id}")

        return 0

    except Exception as e:
        print_error(f"Failed to check authentication status: {e}")
        return 1


def execute_storage_usage(client: AIDriveClient, args: argparse.Namespace) -> int:
    """Execute storage-usage command."""
    try:
        if not args.quiet:
            print_info("Checking storage usage...")

        result = client.get_storage_usage()

        if args.verbose:
            print_json(result)
        else:
            # Format storage information in a user-friendly way
            print("\n📊 Storage Usage Information")
            print(f"{'─' * 40}")
            print(f"Plan: {result.plan}")
            print(f"Quota: {result.quota_gb:.2f} GB ({result.quota_bytes:,} bytes)")
            print(f"Used: {result.used_gb:.2f} GB ({result.used_bytes:,} bytes)")
            print(
                f"Available: {result.available_gb:.2f} GB ({result.available_bytes:,} bytes)"
            )
            print(f"Usage: {result.used_percentage:.1f}%")

            # Visual progress bar
            bar_width = 30
            filled = int((result.used_percentage / 100) * bar_width)
            bar = "█" * filled + "░" * (bar_width - filled)
            print(f"\n[{bar}] {result.used_percentage:.1f}%")

        if not args.quiet:
            if result.used_percentage > 90:
                print_info("⚠️  Storage usage is above 90%!")
            elif result.used_percentage > 75:
                print_info("Storage usage is above 75%")

        return 0
    except Exception as e:
        print_error(f"Failed to get storage usage: {e}")
        return 1


def main() -> int:
    """Main CLI entry point."""
    parser = create_parser()
    args = parser.parse_args()

    # Show help if no command provided
    if not args.command:
        parser.print_help()
        return 0

    try:
        # Get authentication token
        token = args.token or os.environ.get("GENSPARK_TOKEN")
        if not token:
            print_error(
                "Authentication token required. Provide via --token or "
                "set GENSPARK_TOKEN environment variable."
            )
            return 1

        # Initialize client
        client = AIDriveClient(
            token=token,
            base_url=args.base_url,
            api_prefix=args.api_prefix,
            route_identifier=args.route_identifier,
            environment_id=args.environment_id,
        )
        if args.verbose:
            print_info(f"Using token: {token[:8]}...")
            print_info(f"Connected to AIDrive at: {client.base_url}")

        # Execute command
        command_map = {
            "list": execute_list,
            "ls": execute_list,
            "upload": execute_upload,
            "up": execute_upload,
            "download": execute_download,
            "down": execute_download,
            "dl": execute_download,
            "mkdir": execute_mkdir,
            "move": execute_move,
            "mv": execute_move,
            "rename": execute_move,
            "delete": execute_delete,
            "del": execute_delete,
            "rm": execute_delete,
            "check-auth": execute_check_auth,
            "auth": execute_check_auth,
            "storage-usage": execute_storage_usage,
            "usage": execute_storage_usage,
            "quota": execute_storage_usage,
        }

        if args.command in command_map:
            return command_map[args.command](client, args)
        else:
            print_error(f"Unknown command: {args.command}")
            return 1

    except AIDriveError as e:
        print_error(f"AIDrive API Error: {e}")
        if args.verbose and hasattr(e, "response") and e.response:
            print("\nDetailed error response:")
            if isinstance(e.response, str):
                print(e.response)
            else:
                print_json(e.response)
        return getattr(e, "status_code", 1)

    except KeyboardInterrupt:
        print_info("\nOperation cancelled by user")
        return 130

    except Exception as e:
        print_error(f"Unexpected error: {e}")
        if args.verbose:
            import traceback

            traceback.print_exc()
        return 2


if __name__ == "__main__":
    sys.exit(main())
